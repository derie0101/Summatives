/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sg.flooringmastery;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import sg.flooringmastery.daos.FlooringDao;
import sg.flooringmastery.daos.FlooringDaoException;
import sg.flooringmastery.daos.FlooringTemplateDao;
import sg.flooringmastery.models.Order;
import sg.flooringmastery.models.Product;
import sg.flooringmastery.models.Tax;

/**
 *
 * @author dsmelser
 */
@SpringBootApplication
public class App {

//    @Autowired
//    FlooringDao dao;

    public static void main(String[] args) throws FlooringDaoException {

        SpringApplication.run(App.class, args);
    }

}
