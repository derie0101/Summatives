/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sg.flooringmastery.daos;

import java.time.LocalDate;
import java.util.List;
import sg.flooringmastery.models.Order;

/**
 *
 * @author dsmelser
 */
public interface FlooringDao {
    
    //getOrdersByDate       SELECT
    List<Order> getOrdersByDate( LocalDate date ) throws FlooringDaoException;
    //getOrderById          SELECT
    Order getOrderById( int id ) throws FlooringDaoException;
    //addOrder              INSERT
    Order addOrder( Order toAdd ) throws FlooringDaoException;
    //editOrder             UPDATE
    void editOrder( Order edited ) throws FlooringDaoException;
    //removeOrder           DELETE
    void removeOrder( int id ) throws FlooringDaoException;
    
    void removeState( int id ) throws FlooringDaoException;

    void deleteAllOrders() throws FlooringDaoException;;
}
