/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sg.flooringmastery.models;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author dsmelser
 */
public class Order {
    
    private int id;
    
    private LocalDate date;

    private List<Customer> customers;
    
    private BigDecimal area;
    
    private Tax orderTax;
    
    private Product orderProd;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the date
     */
    public LocalDate getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(LocalDate date) {
        this.date = date;
    }

    /**
     * @return the area
     */
    public BigDecimal getArea() {
        return area;
    }

    /**
     * @param area the area to set
     */
    public void setArea(BigDecimal area) {
        this.area = area;
    }

    /**
     * @return the orderTax
     */
    public Tax getOrderTax() {
        return orderTax;
    }

    /**
     * @param orderTax the orderTax to set
     */
    public void setOrderTax(Tax orderTax) {
        this.orderTax = orderTax;
    }

    /**
     * @return the orderProd
     */
    public Product getOrderProd() {
        return orderProd;
    }

    /**
     * @param orderProd the orderProd to set
     */
    public void setOrderProd(Product orderProd) {
        this.orderProd = orderProd;
    }

    /**
     * @return the customers
     */
    public List<Customer> getCustomers() {
        return customers;
    }

    /**
     * @param customers the customers to set
     */
    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }
    
    
    
    
    
    
    
}
