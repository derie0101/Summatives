/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sg.flooringmastery.daos;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import sg.flooringmastery.models.Customer;
import sg.flooringmastery.models.Order;
import sg.flooringmastery.models.Product;
import sg.flooringmastery.models.Tax;

/**
 *
 * @author dsmelser
 */
@Component
public class FlooringTemplateDao implements FlooringDao {

    @Autowired
    private JdbcTemplate template;
    
    private String orderQuery = "SELECT o.*, t.StateAbbrev, t.TaxRate, p.ProductType, p.MatUnitCost, p.LabUnitCost"+
                    " FROM orders o" +
                    " INNER JOIN products p ON o.ProdId = p.Id" +
                    " INNER JOIN taxes t on o.TaxId = t.Id";

    @Override
    public List<Order> getOrdersByDate(LocalDate date) throws FlooringDaoException {
        
        String query = orderQuery + " WHERE OrderDate = ?";
        List<Order> toReturn = template.query(query, new OrderMapper(), date);
        
        for( Order toFinish : toReturn ){
            List<Customer> associatedCustomers = getCustomersByOrder( toFinish.getId() );
            toFinish.setCustomers(associatedCustomers);
        }
        
        return toReturn;
    }

    @Override
    public Order getOrderById(int id) throws FlooringDaoException {
        
        String query = orderQuery + " WHERE o.Id = ?";
        
        Order toReturn = template.queryForObject(query, new OrderMapper(), id);
        
        List<Customer> associateCustomers = getCustomersByOrder( toReturn.getId() );
        toReturn.setCustomers(associateCustomers);
        
        
        return toReturn;
    }

    @Override
    @Transactional
    public Order addOrder(Order toAdd) throws FlooringDaoException {
        String insert = "INSERT INTO orders (OrderDate, TaxId, ProdId, Area) VALUES (?,?,?,?)";

        GeneratedKeyHolder holder = new GeneratedKeyHolder();

        PreparedStatementCreator psc = new PreparedStatementCreator(){
            @Override
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException{
                PreparedStatement toReturn = con.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
                
                toReturn.setDate(1, java.sql.Date.valueOf( toAdd.getDate() ));
                toReturn.setInt(2, toAdd.getOrderTax().getId());
                toReturn.setInt(3, toAdd.getOrderProd().getId());
                toReturn.setBigDecimal(4, toAdd.getArea());
                
                return toReturn;
            }
             
        };
        
        template.update(psc, holder);
                
        int generatedId = holder.getKey().intValue();
        
        toAdd.setId(generatedId);
        
        toAdd.getCustomers().stream().map((toLink) -> toLink.getId()).forEach((custId) -> {
            template.update("INSERT INTO customerorders ( CustId, OrderId ) VALUES(?, ?)", custId, generatedId);
        });
        
        return toAdd;
    }

    @Override
    public void editOrder(Order edited) throws FlooringDaoException {
        
        String updateStatement = "UPDATE orders\n" +
            "SET OrderDate = ?,\n" +
            "TaxId = ?,\n" +
            "ProdId = ?,\n" +
            "Area = ?\n" +
            "WHERE Id = ?";
        
        
        int rowsAffected = template.update(
                updateStatement,
                edited.getDate(),
                edited.getOrderTax().getId(),
                edited.getOrderProd().getId(),
                edited.getArea(),
                edited.getId()
                );

        if( rowsAffected == 0 ){
            throw new FlooringDaoException( "Could not edit order with id = " + edited.getId() );
        }
        
        if( rowsAffected > 1 ){
            throw new FlooringDaoException( "ERROR: OrderId IS NOT UNIQUE FOR orders TABLE." );

        }
        
        //destroy the old relationships
        template.update( "DELETE FROM customerorders WHERE OrderId = ?", edited.getId() );
        
        //add back the relationships after we destroyed the old ones
        edited.getCustomers().stream().map((toLink) -> toLink.getId()).forEach((custId) -> {
            template.update("INSERT INTO customerorders ( CustId, OrderId ) VALUES(?, ?)", custId, edited.getId());
        });
    }

    @Override
    public void removeOrder(int id) throws FlooringDaoException {
        String deleteStatement = "DELETE FROM orders WHERE Id = ?";
        
        int rowsAffected = template.update(deleteStatement, id);
        
        if( rowsAffected == 0 ){
            throw new FlooringDaoException( "Could not delete order with id = " + id );
        }
        
        if( rowsAffected > 1 ){
            throw new FlooringDaoException( "ERROR: OrderId IS NOT UNIQUE FOR orders TABLE." );

        }        
    } 

    @Override
    public void removeState(int id) throws FlooringDaoException {
        String custOrderDelete = "DELETE FROM customerorders \n" +
            "WHERE OrderId IN ( SELECT Id FROM orders WHERE TaxId = ? )";
        
        int rowsAffected = template.update(custOrderDelete, id);
        
        String orderDelete = "DELETE FROM orders WHERE TaxId = ?";
        
        rowsAffected = template.update(orderDelete, id);

        String taxDelete = "DELETE FROM taxes WHERE Id = ?";
        rowsAffected = template.update(taxDelete, id);
         if( rowsAffected == 0 ){
            throw new FlooringDaoException( "Could not delete state with id = " + id );
        }
        if( rowsAffected > 1 ){
            throw new FlooringDaoException( "ERROR: Tax ID IS NOT UNIQUE FOR taxes TABLE." );
        }         
    }

    @Override
    public void deleteAllOrders() throws FlooringDaoException {
        String deleteRelationships = "DELETE FROM customerorders";
        template.update(deleteRelationships);
        String deleteStatement = "DELETE FROM orders";
        template.update(deleteStatement);
    }

    private List<Customer> getCustomersByOrder(int orderId) {
        
        String sql = "SELECT c.* \n" +
            "FROM customerorders co\n" +
            "INNER JOIN customers c ON c.Id = co.CustId\n" +
            "WHERE OrderId = ?";
        
        List<Customer> toReturn = template.query(sql, new CustomerMapper(), orderId);
        
        
        return toReturn;

    }

    private class OrderMapper implements RowMapper<Order> {

        @Override
        public Order mapRow(ResultSet results, int rowNum) throws SQLException {
            Order toAdd = new Order();

            toAdd.setId(results.getInt("Id"));
            //toAdd.setCustomerName(results.getString("CustName"));
            toAdd.setArea(results.getBigDecimal("Area"));
            toAdd.setDate(LocalDate.parse(results.getString("OrderDate")));

            Tax orderTax = new Tax();
            orderTax.setId(results.getInt("TaxId"));
            orderTax.setState(results.getString("StateAbbrev"));
            orderTax.setTaxRate(results.getBigDecimal("TaxRate"));

            toAdd.setOrderTax(orderTax);

            Product orderProd = new Product();
            orderProd.setId(results.getInt("ProdId"));
            orderProd.setMatUnitCost(results.getBigDecimal("MatUnitCost"));
            orderProd.setLabUnitCost(results.getBigDecimal("LabUnitCost"));
            orderProd.setName(results.getString("ProductType"));

            toAdd.setOrderProd(orderProd);
            
            return toAdd;
        }

    }
    
    private class CustomerMapper implements RowMapper<Customer> {

        @Override
        public Customer mapRow(ResultSet results, int rowNum) throws SQLException {
            Customer toReturn = new Customer();
            toReturn.setId( results.getInt("Id") );
            toReturn.setName(results.getString( "CustName" ));
            return toReturn;
        }
        
    }
}
