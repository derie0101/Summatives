/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sg.flooringmastery.daos;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import sg.flooringmastery.TestApplicationConfiguration;
import sg.flooringmastery.models.Customer;
import sg.flooringmastery.models.Order;
import sg.flooringmastery.models.Product;
import sg.flooringmastery.models.Tax;

/**
 *
 * @author dsmelser
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplicationConfiguration.class)
public class FlooringTemplateDaoTest {
    
    @Autowired
    FlooringDao toTest;
    
    public FlooringTemplateDaoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() throws FlooringDaoException {
        toTest.deleteAllOrders();
        
        //insert orders...
        
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getOrdersByDate method, of class FlooringTemplateDao.
     */
    @Test
    public void testGetOrdersByDate() throws Exception {
    }

    /**
     * Test of getOrderById method, of class FlooringTemplateDao.
     */
    @Test
    public void testGetOrderById() throws Exception {
    }

    /**
     * Test of addOrder method, of class FlooringTemplateDao.
     */
    @Test
    public void testAddOrder() throws Exception {
        List<Customer> customers = new ArrayList<>();
        
        Customer c1 = new Customer();
        c1.setName("Alice");
        c1.setId(1);
        
        Customer c2 = new Customer();
        c2.setName("Eugene");
        c2.setId(5);
        
        customers.add(c1);
        customers.add(c2);
        
        Product p = new Product();
        p.setId(2);
        p.setName("Laminate");
        p.setMatUnitCost( new BigDecimal("1.75") );
        p.setLabUnitCost( new BigDecimal("2.10") );
        
        Tax t = new Tax();
        t.setId(2);
        t.setState("PA");
        t.setTaxRate(new BigDecimal("6.75"));
        
        Order toAdd = new Order();
        
        toAdd.setDate( LocalDate.of(2021, 1, 1) );
        toAdd.setArea(new BigDecimal( "1234.56"));
        toAdd.setCustomers(customers);
        toAdd.setOrderProd(p);
        toAdd.setOrderTax(t);

        Order added = toTest.addOrder(toAdd);
        
        int id = added.getId();
        
        Order validationOrder = toTest.getOrderById(id);
        
        
        assertEquals( LocalDate.of( 2021, 1, 1 )  , validationOrder.getDate());
        assertEquals( new BigDecimal( "1234.5600"), validationOrder.getArea()  );
        
        assertEquals( 2, validationOrder.getOrderProd().getId()  );
        assertEquals( "Laminate", validationOrder.getOrderProd().getName() );
        assertEquals( new BigDecimal("1.75"), validationOrder.getOrderProd().getMatUnitCost() );
        assertEquals( new BigDecimal("2.10"), validationOrder.getOrderProd().getLabUnitCost());
        
        assertEquals( 2, validationOrder.getOrderTax().getId() );
        assertEquals( "PA", validationOrder.getOrderTax().getState() );
        assertEquals( new BigDecimal("6.75"), validationOrder.getOrderTax().getTaxRate());
        
        
        assertEquals( 1, validationOrder.getCustomers().get(0).getId() );
        assertEquals( "Alice", validationOrder.getCustomers().get(0).getName());
        
        assertEquals( 5, validationOrder.getCustomers().get(1).getId() );
        assertEquals( "Eugene", validationOrder.getCustomers().get(1).getName());
    }

    /**
     * Test of editOrder method, of class FlooringTemplateDao.
     */
    @Test
    public void testEditOrder() throws Exception {
    }

    /**
     * Test of removeOrder method, of class FlooringTemplateDao.
     */
    @Test
    public void testRemoveOrder() throws Exception {
    }

    /**
     * Test of removeState method, of class FlooringTemplateDao.
     */
    @Test
    public void testRemoveState() throws Exception {
    }
    
}
